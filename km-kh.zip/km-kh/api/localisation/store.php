<?php
// Text
$_['text_success'] = 'Success: Store has been changed!';

// Error
$_['error_store']  = 'Warning: Store could not be found!';