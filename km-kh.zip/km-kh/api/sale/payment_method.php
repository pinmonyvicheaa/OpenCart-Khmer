<?php
// Text
$_['text_success']          = 'Success: Payment method has been set!';

// Error
$_['error_payment_address'] = 'Warning: Payment address required!';
$_['error_payment_method']  = 'Warning: Payment method required!';
$_['error_no_payment']      = 'Warning: No payment options are available!';
$_['error_product']         = 'Warning: Products required!';