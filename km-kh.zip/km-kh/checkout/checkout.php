<?php
// Heading
$_['heading_title'] = 'Checkout';

// Text
$_['text_cart']     = 'Shopping Cart';