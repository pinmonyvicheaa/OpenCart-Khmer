<?php
// Text
$_['text_language'] = 'Language';