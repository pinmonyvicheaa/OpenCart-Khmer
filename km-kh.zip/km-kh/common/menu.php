<?php
// Text
$_['text_category']  = 'Categories';
$_['text_all']       = 'Show All';
