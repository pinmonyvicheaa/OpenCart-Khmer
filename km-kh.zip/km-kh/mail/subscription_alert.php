<?php
// Text
$_['text_subject']              = '%s - Order %s - Canceled Subscription';
$_['text_received']             = 'You have received a canceled subscription.';
$_['text_orders_id']            = 'Order ID:';
$_['text_subscription_id']      = 'Subscription ID';
$_['text_date_added']           = 'Date Added:';
$_['text_subscription_status']  = 'Subscription Status:';
$_['text_comment']              = 'The comments for your subscription are:';
$_['text_canceled']             = 'Success: The Subscription profile has been canceled!';
